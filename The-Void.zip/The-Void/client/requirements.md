## Packages
framer-motion | Smooth animations for list entry and interactions
date-fns | Formatting timestamps relative to now

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  mono: ["var(--font-mono)", "monospace"],
  sans: ["var(--font-sans)", "sans-serif"],
}
