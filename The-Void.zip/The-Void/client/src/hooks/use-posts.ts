import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useEffect } from "react";
import { WS_EVENTS, type Post, type InsertPost } from "@shared/schema";

export function usePosts() {
  const queryClient = useQueryClient();

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    console.log('Connecting to WS:', wsUrl);
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => console.log('WS Connected');
    socket.onerror = (err) => console.error('WS Connection Error:', err);

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === WS_EVENTS.NEW_POST) {
          queryClient.setQueryData([api.posts.list.path], (old: any[] | undefined) => {
            if (!old) return [data.payload];
            if (old.some(p => p.id === data.payload.id)) return old;
            return [data.payload, ...old];
          });
        } else if (data.type === WS_EVENTS.USER_COUNT) {
          window.dispatchEvent(new CustomEvent('ws_message', { detail: data }));
        }
      } catch (err) {
        console.error("WS Error:", err);
      }
    };

    return () => socket.close();
  }, [queryClient]);

  return useQuery({
    queryKey: [api.posts.list.path],
    queryFn: async () => {
      const res = await fetch(api.posts.list.path);
      if (!res.ok) throw new Error("Failed to fetch posts");
      return api.posts.list.responses[200].parse(await res.json());
    },
  });
}

export function usePost(id: number) {
  return useQuery({
    queryKey: [api.posts.get.path, id],
    queryFn: async () => {
      const res = await fetch(api.posts.get.path.replace(":id", id.toString()));
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch post");
      return api.posts.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useDeletePost() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, code }: { id: number; code: string }) => {
      const res = await fetch(api.posts.delete.path.replace(":id", id.toString()), {
        method: api.posts.delete.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
      });

      if (!res.ok) {
        throw new Error("Failed to delete from the void");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.posts.list.path] });
    },
  });
}

export function useCreatePost() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { content: string; code?: string; username?: string; mediaUrl?: string; mediaType?: "image" | "video"; distortion?: string }) => {
      const res = await fetch(api.posts.create.path, {
        method: api.posts.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ message: "Unknown error" }));
        throw new Error(errorData.message || "Failed to post into the void");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.posts.list.path] });
    },
  });
}
