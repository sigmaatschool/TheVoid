import { PostCard } from "@/components/PostCard";
import { DirectMessages } from "@/components/DirectMessages";
import { VoidInput } from "@/components/VoidInput";
import { 
  Loader2, LogIn, User as UserIcon, Volume2, VolumeX, 
  MessageSquare, Type, ZoomIn, ZoomOut, Palette 
} from "lucide-react";
import { useState, useEffect, useRef, useMemo } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { useAudioSystem } from "@/hooks/use-audio-system";
import { usePosts } from "@/hooks/use-posts";

import { WS_EVENTS } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

import { useToast } from "@/hooks/use-toast";

const THEMES = [
  { id: "default", name: "Void", color: "#ffffff" },
  { id: "blood", name: "Blood", color: "#ff0000" },
  { id: "forest", name: "Forest", color: "#00cc00" },
  { id: "deep", name: "Deep", color: "#3b82f6" },
  { id: "amber", name: "Amber", color: "#f59e0b" },
];

export default function Home() {
  const { user, isAuthenticated, isLoading: isAuthLoading } = useAuth();
  const { toast } = useToast();
  const { data: posts, isLoading, error } = usePosts();
  const { playHover, playClick, playEcho, audioContext } = useAudioSystem();
  const [userCount, setUserCount] = useState<number>(0);
  const [isAudioEnabled, setIsAudioEnabled] = useState(false);
  const [showDMs, setShowDMs] = useState(false);
  const [fontSize, setFontSize] = useState(() => Number(localStorage.getItem("void_font_size")) || 16);
  const [fontFamily, setFontFamily] = useState(() => localStorage.getItem("void_font_family") || "Inter");
  const [theme, setTheme] = useState(() => localStorage.getItem("void_theme") || "default");
  
  const humNode = useRef<OscillatorNode | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    localStorage.setItem("void_font_size", String(fontSize));
    localStorage.setItem("void_font_family", fontFamily);
    localStorage.setItem("void_theme", theme);
    document.documentElement.style.setProperty("--app-font-size", `${fontSize}px`);
    document.documentElement.style.setProperty("--app-font-family", fontFamily);
    
    // Update theme class on body
    const body = document.body;
    THEMES.forEach(t => body.classList.remove(`theme-${t.id}`));
    if (theme !== "default") {
      body.classList.add(`theme-${theme}`);
    }
  }, [fontSize, fontFamily, theme]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ 
        x: (e.clientX / window.innerWidth - 0.5) * 20, 
        y: (e.clientY / window.innerHeight - 0.5) * 20 
      });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const toggleAudio = () => {
    if (!isAudioEnabled) {
      if (!audioContext.current) {
        // init is handled by playSound/initContext, but we need it for the hum
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        (audioContext as any).current = ctx;
      }
      const ctx = audioContext.current!;
      if (ctx.state === "suspended") ctx.resume();
      
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(50, ctx.currentTime);
      gain.gain.setValueAtTime(0.02, ctx.currentTime);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      humNode.current = osc;
    } else {
      humNode.current?.stop();
    }
    setIsAudioEnabled(!isAudioEnabled);
  };

  useEffect(() => {
    const handleNewPost = (e: any) => {
      if (e.detail?.type === 'new_post' && isAudioEnabled) {
        playEcho();
      }
    };
    window.addEventListener('ws_message', handleNewPost);
    return () => window.removeEventListener('ws_message', handleNewPost);
  }, [isAudioEnabled, playEcho]);

  const onInteraction = (type: 'hover' | 'click') => {
    if (isAudioEnabled) {
      if (type === 'hover') playHover();
      else playClick();
    }
  };

  const [globalImage, setGlobalImage] = useState<string | null>(null);
  const [adminCode, setAdminCode] = useState(() => {
    try {
      return localStorage.getItem('void_admin_code') || "";
    } catch {
      return "";
    }
  });

  const isSystemAdmin = useMemo(() => {
    if (!user) return false;
    const userId = String(user.id);
    return userId === "41825561" || userId === "49721790";
  }, [user]);

  const isAdmin = isSystemAdmin || adminCode === "Liam" || adminCode === "hunter";

  const triggerAdminAction = async (action: string, payload: any = {}) => {
    if (!isAdmin) {
      toast({
        title: "Unauthorized",
        description: "The void ignores your command.",
        variant: "destructive",
      });
      return;
    }
    try {
      await apiRequest("POST", "/api/admin/action", { 
        code: adminCode, 
        action, 
        payload 
      });
    } catch (err) {
      console.error("Admin action failed:", err);
    }
  };

  useEffect(() => {
    const handleAdminAction = (e: any) => {
      if (e.detail?.type === WS_EVENTS.ADMIN_ACTION) {
        const { action, imageUrl } = e.detail.payload;
        if (action === 'confetti') {
          import('canvas-confetti').then(confetti => {
            confetti.default({
              particleCount: 150,
              spread: 70,
              origin: { y: 0.6 },
              colors: ['#ffffff', '#333333', '#666666', '#999999', '#cccccc']
            });
          });
          toast({
            title: "CHAOS MANIFESTED",
            description: "The void erupts in celebration.",
          });
        } else if (action === 'show_image') {
          setGlobalImage(imageUrl);
          toast({
            title: "A VISION APPEARS",
            description: "An image emerges from the darkness.",
          });
          setTimeout(() => setGlobalImage(null), 10000);
        }
      }
    };
    window.addEventListener('ws_message', handleAdminAction);
    return () => window.removeEventListener('ws_message', handleAdminAction);
  }, []);

  useEffect(() => {
    const handleStorageChange = () => {
      setAdminCode(localStorage.getItem('void_admin_code') || "");
    };
    window.addEventListener('storage_code_updated', handleStorageChange);

    const handleUserCount = (e: any) => {
      if (e.detail?.type === 'user_count') {
        setUserCount(e.detail.payload.count);
      }
    };
    window.addEventListener('ws_message', handleUserCount);

    return () => {
      window.removeEventListener('storage_code_updated', handleStorageChange);
      window.removeEventListener('ws_message', handleUserCount);
    };
  }, []);

  const sortedPosts = posts?.sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <div 
      className={`min-h-screen selection:bg-white selection:text-black pb-24 relative overflow-hidden transition-colors duration-700 ${
        theme === 'blood' ? 'bg-[#050000]' : 
        theme === 'forest' ? 'bg-[#000500]' :
        theme === 'deep' ? 'bg-[#000005]' :
        theme === 'amber' ? 'bg-[#050300]' :
        'bg-black'
      }`}
      style={{ fontSize: "var(--app-font-size)", fontFamily: "var(--app-font-family)" }}
    >
      <div className="fixed top-4 left-4 z-50 pointer-events-none flex flex-col gap-2">
        <span className="text-[9px] font-mono text-zinc-800 uppercase tracking-[0.3em] select-none">
          VOID v0.1.6
        </span>
        {isAdmin && (
          <div className="pointer-events-auto flex gap-2 mt-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="h-6 text-[8px] uppercase tracking-tighter bg-black/50 border-zinc-800 hover:bg-zinc-900"
              onClick={() => triggerAdminAction('confetti')}
            >
              Chaos
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="h-6 text-[8px] uppercase tracking-tighter bg-black/50 border-zinc-800 hover:bg-zinc-900"
              onClick={() => {
                const url = prompt("Image URL to manifest?");
                if (url) triggerAdminAction('show_image', { imageUrl: url });
              }}
            >
              Manifest
            </Button>
          </div>
        )}
      </div>

      {globalImage && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-500 cursor-pointer"
          onClick={() => setGlobalImage(null)}
        >
          <div className="relative max-w-[90vw] max-h-[90vh] animate-in zoom-in duration-700">
            <img 
              src={globalImage} 
              alt="Admin Manifestation" 
              className="rounded border-4 border-white/10 shadow-[0_0_50px_rgba(255,255,255,0.1)] max-w-full max-h-full object-contain"
            />
          </div>
        </div>
      )}
      
      <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 bg-zinc-950/80 border border-zinc-900 rounded p-1 backdrop-blur-sm">
        <Button 
          variant="ghost" 
          size="icon" 
          onMouseEnter={() => onInteraction('hover')}
          onClick={() => { onInteraction('click'); setFontSize(s => Math.max(12, s - 2)); }}
          className="h-6 w-6 text-zinc-600 hover:text-zinc-300"
        >
          <ZoomOut className="w-3 h-3" />
        </Button>
        <span className="text-[10px] font-mono text-zinc-700 w-4 text-center">{fontSize}</span>
        <Button 
          variant="ghost" 
          size="icon" 
          onMouseEnter={() => onInteraction('hover')}
          onClick={() => { onInteraction('click'); setFontSize(s => Math.min(24, s + 2)); }}
          className="h-6 w-6 text-zinc-600 hover:text-zinc-300"
        >
          <ZoomIn className="w-3 h-3" />
        </Button>
        <div className="w-px h-3 bg-zinc-900 mx-1" />
        <Button 
          variant="ghost" 
          size="icon" 
          onMouseEnter={() => onInteraction('hover')}
          onClick={() => { onInteraction('click'); setFontFamily(f => f === "Inter" ? "JetBrains Mono" : "Inter"); }}
          className="h-6 w-6 text-zinc-600 hover:text-zinc-300"
        >
          <Type className="w-3 h-3" />
        </Button>
        <div className="w-px h-3 bg-zinc-900 mx-1" />
        <div className="flex flex-wrap justify-center gap-1.5 md:gap-2 px-4">
          {THEMES.map((t) => (
            <button
              key={t.id}
              onClick={() => { onInteraction('click'); setTheme(t.id); }}
              onMouseEnter={() => onInteraction('hover')}
              className={`w-4 h-4 md:w-3 md:h-3 rounded-full border border-zinc-900 transition-all ${theme === t.id ? 'scale-125 ring-1 ring-zinc-500' : 'opacity-50 hover:opacity-100'}`}
              style={{ backgroundColor: t.color }}
              title={t.name}
            />
          ))}
        </div>
      </div>

      <div 
        className="fixed inset-0 pointer-events-none z-0 opacity-20"
        style={{
          background: 'radial-gradient(circle at 50% 50%, #111 0%, transparent 100%)',
          transform: `translate(${mousePos.x}px, ${mousePos.y}px)`
        }}
      />
      <div className="fixed inset-0 bg-black opacity-100 pointer-events-none z-[-1]"></div>
      
      <header className="pt-16 md:pt-24 pb-8 md:pb-12 px-4 md:px-6 text-center relative z-10">
        <div className="absolute top-4 md:top-8 left-4 md:left-8 flex items-center gap-2 md:gap-4">
          <Button 
            variant="ghost" 
            size="icon" 
            onMouseEnter={() => onInteraction('hover')}
            onClick={() => { onInteraction('click'); toggleAudio(); }}
            className="text-zinc-700 hover:text-zinc-300 h-8 w-8 md:h-10 md:w-10"
          >
            {isAudioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </Button>
        </div>
        <div className="absolute top-4 md:top-8 right-4 md:right-8 flex items-center gap-2 md:gap-4">
          {isAuthenticated && (
            <Button
              variant="ghost"
              size="icon"
              onMouseEnter={() => onInteraction('hover')}
              onClick={() => { onInteraction('click'); setShowDMs(!showDMs); }}
              className="text-zinc-700 hover:text-zinc-300 relative h-8 w-8 md:h-10 md:w-10"
            >
              <MessageSquare className="w-4 h-4" />
            </Button>
          )}
          {!isAuthLoading && (
            isAuthenticated ? (
              <div className="flex items-center gap-2 md:gap-3">
                <div className="flex flex-col items-end hidden xs:flex">
                  <span className="text-[9px] md:text-[10px] font-mono text-zinc-400 uppercase tracking-widest truncate max-w-[80px] md:max-w-none">
                    {user?.firstName || 'Connected'}
                  </span>
                  <a href="/api/logout" className="text-[8px] md:text-[9px] font-mono text-zinc-600 hover:text-zinc-400 uppercase tracking-[0.2em] transition-colors">
                    Disconnect
                  </a>
                </div>
                {user?.profileImageUrl ? (
                  <img src={user.profileImageUrl} alt="Profile" className="w-7 h-7 md:w-8 md:h-8 rounded border border-zinc-800" />
                ) : (
                  <div className="w-7 h-7 md:w-8 md:h-8 rounded border border-zinc-800 flex items-center justify-center bg-zinc-950">
                    <UserIcon className="w-3 h-3 md:w-4 md:h-4 text-zinc-800" />
                  </div>
                )}
              </div>
            ) : (
              <a href="/api/login" className="flex items-center gap-1 md:gap-2 px-2 md:px-3 py-1 md:py-1.5 rounded border border-zinc-900 bg-zinc-950/50 hover:bg-zinc-900 text-[9px] md:text-[10px] font-mono text-zinc-400 hover:text-zinc-200 uppercase tracking-widest transition-all">
                <LogIn className="w-3 h-3" /> <span className="hidden xs:inline">Connect</span>
              </a>
            )
          )}
        </div>
        <h1 className={`text-4xl sm:text-6xl md:text-8xl font-bold font-mono tracking-tighter mb-2 md:mb-4 text-glow select-none transition-colors duration-700 ${
          theme === 'blood' ? 'text-red-600' :
          theme === 'forest' ? 'text-green-600' :
          theme === 'deep' ? 'text-blue-600' :
          theme === 'amber' ? 'text-amber-600' :
          'text-white'
        }`}>
          VOID
        </h1>
        <p className="text-zinc-500 font-mono text-[10px] sm:text-xs md:text-sm tracking-[0.15em] md:tracking-[0.2em] uppercase px-4">
          Vanish out into darkness
        </p>
        {userCount > 0 && (
          <div className="mt-4 flex items-center justify-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            <span className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest">
              {userCount} {userCount === 1 ? 'Soul' : 'Souls'} in the void
            </span>
          </div>
        )}
      </header>

      <main className="container max-w-3xl mx-auto px-6 relative z-10">
        {showDMs && isAuthenticated ? (
          <DirectMessages onClose={() => setShowDMs(false)} />
        ) : (
          <>
            <VoidInput />

            <div className="space-y-8 mt-16">
              {isLoading ? (
                <div className="flex flex-col items-center justify-center py-20 gap-4 text-zinc-800">
                  <Loader2 className="w-8 h-8 animate-spin" />
                  <p className="font-mono text-xs uppercase tracking-widest">Listening...</p>
                </div>
              ) : error ? (
                <div className="text-center py-20 text-red-900/50 font-mono text-sm uppercase tracking-widest border border-red-900/20 p-8 rounded">
                  The void is unreachable
                </div>
              ) : sortedPosts?.length === 0 ? (
                <div className="text-center py-20 text-zinc-800 font-mono text-sm uppercase tracking-widest">
                  Silence reigns
                </div>
              ) : (
                <div className="flex flex-col gap-8">
                  {sortedPosts?.map((post, index) => (
                    <PostCard key={post.id} post={post} index={index} adminCode={adminCode} />
                  ))}
                </div>
              )}
            </div>
          </>
        )}
      </main>

      <footer className="fixed bottom-6 left-0 right-0 text-center pointer-events-none">
        <p className="text-[10px] text-zinc-900 font-mono uppercase tracking-[0.3em]">
          VOID v0.1.6
        </p>
      </footer>
    </div>
  );
}
