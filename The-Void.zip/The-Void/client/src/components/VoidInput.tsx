import { useState, useEffect } from "react";
import { usePosts, useCreatePost } from "@/hooks/use-posts";
import { Loader2, SendHorizontal, Image as ImageIcon, Video, User as UserIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ObjectUploader } from "./ObjectUploader";
import { useAudioSystem } from "@/hooks/use-audio-system";
import { useAuth } from "@/hooks/use-auth";
import confetti from "canvas-confetti";

export function VoidInput() {
  const { user } = useAuth();
  const [content, setContent] = useState("");
  const [code, setCode] = useState("");
  const [username, setUsername] = useState(() => localStorage.getItem("void_username") || "");
  const [distortion, setDistortion] = useState<"none" | "glitch" | "blur" | "upside-down" | "vapor">("none");

  useEffect(() => {
    if (user?.firstName) {
      const name = `${user.firstName}${user.lastName ? ` ${user.lastName}` : ''}`;
      setUsername(name);
      localStorage.setItem("void_username", name);
    }
  }, [user]);

  const [media, setMedia] = useState<{ url: string; type: "image" | "video" } | null>(null);
  const { playHover, playClick } = useAudioSystem();
  const { mutate, isPending } = useCreatePost();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && !media) return;

    const trimmedCode = code.trim();
    if (trimmedCode === "Liam" || trimmedCode === "hunter") {
      localStorage.setItem('void_admin_code', trimmedCode);
      window.dispatchEvent(new Event('storage_code_updated'));
    } else {
      localStorage.removeItem('void_admin_code');
      window.dispatchEvent(new Event('storage_code_updated'));
    }

    // @ts-ignore
    mutate({ 
      content: content.trim() || "Echo", 
      code,
      username: username.trim() || undefined,
      mediaUrl: media?.url,
      mediaType: media?.type,
      distortion
    }, {
      onSuccess: () => {
        setContent("");
        setMedia(null);
        setDistortion("none");
        
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#ffffff', '#333333', '#000000']
        });

        toast({
          title: "Echo released",
          description: "Your thought has drifted into the void.",
        });
      },
      onError: (err: any) => {
        toast({
          title: "Silence",
          description: err.message || "The void rejected your echo. Try again.",
          variant: "destructive",
        });
      },
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as unknown as React.FormEvent);
    }
  };

  const handleUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newUsername = e.target.value;
    setUsername(newUsername);
    localStorage.setItem("void_username", newUsername);
  };

  const handleUploadComplete = (result: any) => {
    const successful = result.successful?.[0];
    if (successful) {
      const type = successful.type?.startsWith("video") ? "video" : "image";
      const objectPath = successful.response?.body?.objectPath;
      
      if (objectPath) {
        // Use the objectPath directly, ensuring it doesn't have double /objects
        const cleanPath = objectPath.startsWith('/objects/') 
          ? objectPath 
          : `/objects/${objectPath.replace(/^\//, '')}`;
        
        setMedia({ url: cleanPath, type });
        toast({ title: "Media attached", description: "Your echo will carry this vision." });
      } else {
        // Fallback: extract the UUID from the upload URL
        try {
          const url = successful.uploadURL;
          const urlObj = new URL(url);
          const pathParts = urlObj.pathname.split('/');
          const uuid = pathParts[pathParts.length - 1];
          // Uploads usually go into the .private/uploads directory
          setMedia({ url: `/objects/uploads/${uuid}`, type });
          toast({ title: "Media attached", description: "Your echo will carry this vision." });
        } catch (e) {
          console.error("Failed to parse upload URL", e);
        }
      }
    }
  };

  const isSystemAdmin = user && (String(user.id) === "41825561" || String(user.id) === "49721790");
  const isLiam = isSystemAdmin || code.trim() === "Liam" || code.trim() === "hunter";

  return (
    <div className="w-full max-w-2xl mx-auto mb-8 md:mb-16 relative group px-2 md:px-0">
      <div className="flex flex-col sm:flex-row gap-3 md:gap-4 mb-4">
        <div className="relative flex-1">
          <UserIcon className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-zinc-700" />
          <input
            type="text"
            value={username}
            onChange={handleUsernameChange}
            placeholder="Identity (optional)"
            className="w-full bg-zinc-950/50 border border-zinc-900 rounded px-8 py-2 md:py-1 text-[10px] font-mono text-zinc-300 focus:outline-none focus:border-zinc-700 transition-colors uppercase tracking-widest placeholder:text-zinc-800"
          />
        </div>
        <div className="flex gap-2">
          <select 
            value={distortion}
            onMouseEnter={playHover}
            onChange={(e) => { playClick(); setDistortion(e.target.value as any); }}
            className="flex-1 sm:flex-none bg-zinc-950/50 border border-zinc-900 rounded px-2 py-2 md:py-1 text-[10px] font-mono text-zinc-500 uppercase tracking-widest focus:outline-none"
          >
            <option value="none">Clear</option>
            <option value="glitch">Glitch</option>
            <option value="blur">Blur</option>
            <option value="upside-down">Invert</option>
            <option value="vapor">Vapor</option>
          </select>
          <input
            type="text"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="Access Code"
            className={`flex-1 sm:w-32 bg-zinc-950/50 border ${isLiam ? 'border-green-500 text-green-500' : 'border-zinc-900 text-zinc-600'} rounded px-2 py-2 md:py-1 text-[10px] font-mono focus:outline-none focus:border-zinc-700 transition-colors uppercase tracking-widest placeholder:text-zinc-800`}
          />
        </div>
      </div>

      <form onSubmit={handleSubmit} className="relative">
        <div className="relative flex flex-col bg-zinc-950 border border-zinc-800 rounded-lg shadow-2xl focus-within:border-zinc-600 focus-within:ring-1 focus-within:ring-zinc-600 transition-all duration-300">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Shout into the void..."
            className="w-full bg-transparent border-none text-zinc-100 placeholder:text-zinc-600 px-6 py-4 text-lg focus:outline-none font-mono resize-none min-h-[100px]"
            disabled={isPending}
          />
          
          {media && (
            <div className="px-6 pb-4">
              <div className="relative inline-block group/media">
                {media.type === "image" ? (
                  <img src={media.url} alt="Attached" className="max-h-32 rounded border border-zinc-800" />
                ) : (
                  <div className="flex items-center gap-2 text-zinc-500 font-mono text-xs uppercase p-2 border border-zinc-800 rounded">
                    <Video className="w-4 h-4" /> Attached Video
                  </div>
                )}
                <button 
                  type="button"
                  onClick={() => setMedia(null)}
                  className="absolute -top-2 -right-2 bg-red-900 text-white rounded-full w-5 h-5 flex items-center justify-center text-[10px] opacity-0 group-hover/media:opacity-100 transition-opacity"
                >
                  ×
                </button>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between px-4 py-3 border-t border-zinc-900/50 bg-zinc-950/20">
            <div className="flex gap-2">
              <ObjectUploader
                onGetUploadParameters={async (file) => {
                  const res = await fetch("/api/uploads/request-url", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      name: file.name,
                      size: file.size,
                      contentType: file.type || "image/jpeg",
                    }),
                  });
                  if (!res.ok) throw new Error("Failed to get upload URL");
                  const { uploadURL } = await res.json();
                  return {
                    method: "PUT",
                    url: uploadURL,
                    headers: { "Content-Type": file.type || "image/jpeg" },
                  };
                }}
                onComplete={handleUploadComplete}
                maxNumberOfFiles={1}
                buttonClassName="bg-transparent hover:bg-zinc-900/50 border-none h-8 w-8 p-0 no-default-hover-elevate no-default-active-elevate"
              >
                <ImageIcon className="w-4 h-4 text-zinc-600" />
              </ObjectUploader>
            </div>
            
            <button
              type="submit"
              onMouseEnter={playHover}
              onClick={playClick}
              disabled={(!content.trim() && !media) || isPending}
              className="p-2 text-zinc-400 hover:text-white disabled:opacity-30 disabled:hover:text-zinc-400 transition-colors"
            >
              {isPending ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <SendHorizontal className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>
      </form>
      <div className="mt-2 text-center">
        <p className="text-xs text-zinc-700 font-mono tracking-widest uppercase opacity-0 group-hover:opacity-100 transition-opacity duration-500">
          Only echoes remain
        </p>
      </div>
    </div>
  );
}
