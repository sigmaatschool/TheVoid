import { useAuth } from "@/hooks/use-auth";
import { formatDistanceToNow } from "date-fns";
import { type Post } from "@shared/schema";
import { Trash2, Heart, Sparkles, Wind, VolumeX, Volume2 } from "lucide-react";
import { useDeletePost } from "@/hooks/use-posts";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { useAudioSystem } from "@/hooks/use-audio-system";

interface PostCardProps {
  post: Post;
  index: number;
  adminCode?: string;
}

const REACTION_ICONS: Record<string, any> = {
  heart: Heart,
  sparkle: Sparkles,
  ripple: Wind,
  skull: ({ className }: { className?: string }) => (
    <span className={`text-[12px] leading-none select-none ${className}`}>💀</span>
  ),
  void: ({ className }: { className?: string }) => (
    <span className={`text-[12px] leading-none select-none ${className}`}>🕳️</span>
  ),
};

export function PostCard({ post, index, adminCode }: PostCardProps) {
  const { user } = useAuth();
  const { playHover, playClick } = useAudioSystem();
  const { mutate: deletePost, isPending: isDeleting } = useDeletePost();
  const { toast } = useToast();

  const muteMutation = useMutation({
    mutationFn: async (duration?: number) => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/mute`, { duration });
      return res.json();
    },
    onSuccess: (updatedPost: Post) => {
      queryClient.setQueryData(["/api/posts"], (old: Post[] | undefined) => {
        return old?.map(p => p.id === updatedPost.id ? updatedPost : p);
      });
      const message = updatedPost.isMuted 
        ? (updatedPost.mutedUntil 
            ? `Silenced for ${Math.round((new Date(updatedPost.mutedUntil).getTime() - Date.now()) / 60000)} minutes.` 
            : "Silenced eternally.")
        : "Their voice returns to the darkness.";
      
      toast({
        title: updatedPost.isMuted ? "Echo Silenced" : "Echo Restored",
        description: message,
      });
    }
  });

  const handleMuteClick = () => {
    playClick();
    if (post.isMuted) {
      muteMutation.mutate();
    } else {
      const minutesStr = prompt("How many minutes should the silence last? (Leave empty for eternity)", "60");
      if (minutesStr === null) return;
      const minutes = minutesStr === "" ? undefined : parseInt(minutesStr);
      muteMutation.mutate(minutes);
    }
  };
  
  const isSystemAdmin = user && (String(user.id) === "41825561" || String(user.id) === "49721790");
  const isAdmin = isSystemAdmin || adminCode === "Liam" || adminCode === "hunter";

  if (post.isMuted && !isAdmin) {
    const isStillMuted = !post.mutedUntil || new Date(post.mutedUntil).getTime() > Date.now();
    if (isStillMuted) {
      return (
        <div className="group relative opacity-40 select-none py-4 border-l border-zinc-900/50 pl-4">
          <span className="text-xs font-mono text-zinc-800 uppercase tracking-widest italic">
            [ This echo has been silenced by the void {post.mutedUntil && `until ${new Date(post.mutedUntil).toLocaleTimeString()}`} ]
          </span>
        </div>
      );
    }
  }

  const reactMutation = useMutation({
    mutationFn: async (type: string) => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/react`, { type });
      return res.json();
    },
    onSuccess: (updatedPost: Post) => {
      queryClient.setQueryData(["/api/posts"], (old: Post[] | undefined) => {
        return old?.map(p => p.id === updatedPost.id ? updatedPost : p);
      });
    }
  });

  const reactions = JSON.parse(post.reactions || "[]");

  const distortionClass = post.distortion === 'glitch' 
    ? 'animate-pulse skew-x-1' 
    : post.distortion === 'blur' 
    ? 'blur-[0.5px] hover:blur-none transition-all' 
    : post.distortion === 'upside-down'
    ? 'rotate-180 inline-block'
    : post.distortion === 'vapor'
    ? 'text-transparent bg-clip-text bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-500 animate-pulse'
    : '';

  return (
    <div
      className="group relative"
      style={{
        animation: `fadeUp 0.4s ease-out forwards ${index * 0.05}s`,
        opacity: 0,
        transform: 'translateY(20px)'
      }}
    >
      {isAdmin && (
        <button
          onClick={() => {
            playClick();
            deletePost({ id: post.id, code: adminCode! }, {
              onSuccess: () => {
                toast({
                  title: "Echo vanished",
                  description: "The void has swallowed the echo.",
                });
              }
            });
          }}
          disabled={isDeleting}
          className="absolute -left-12 top-4 p-2 text-zinc-800 hover:text-red-900 transition-colors opacity-0 group-hover:opacity-100 disabled:opacity-50 z-20"
          data-testid={`button-delete-post-${post.id}`}
          title="Vanish Echo"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      )}
      {isAdmin && (
        <button
          onClick={handleMuteClick}
          disabled={muteMutation.isPending}
          className="absolute -left-12 top-12 p-2 text-zinc-800 hover:text-yellow-600 transition-colors opacity-0 group-hover:opacity-100 disabled:opacity-50 z-20"
          data-testid={`button-mute-post-${post.id}`}
          title={post.isMuted ? "Unmute Echo" : "Mute Echo"}
        >
          {post.isMuted ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>
      )}
      <div className="absolute inset-0 bg-gradient-to-br from-zinc-800/10 to-transparent rounded-none opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
      
      <div className={`border-l ${post.isGolden ? 'border-yellow-500/50' : 'border-zinc-900'} pl-4 md:pl-6 py-3 md:py-4 hover:border-zinc-700 transition-colors duration-300 relative`}>
        <div className="flex items-start justify-between gap-2 md:gap-4">
          <div className="flex-1 min-w-0">
            {post.username && (
              <div className="mb-1.5 md:mb-2 flex items-center gap-2">
                <span className="text-[9px] md:text-[10px] font-mono text-zinc-500 uppercase tracking-[0.2em] truncate">
                  {post.username}
                </span>
                <div className="h-px w-3 md:w-4 bg-zinc-900" />
              </div>
            )}
            <p className={`text-base md:text-lg leading-relaxed font-light font-sans tracking-wide transition-colors duration-700 break-words ${
              post.isMuted ? 'opacity-20 select-none blur-[2px] grayscale' :
              post.isGolden ? 'text-yellow-400 text-glow-gold' : 
              document.body.classList.contains('theme-blood') ? 'text-red-400/80' :
              document.body.classList.contains('theme-forest') ? 'text-green-400/80' :
              document.body.classList.contains('theme-deep') ? 'text-blue-400/80' :
              document.body.classList.contains('theme-amber') ? 'text-amber-400/80' :
              'text-zinc-300'
            } ${distortionClass}`}>
              {post.content}
            </p>
          </div>
          <div className="flex flex-col gap-2 shrink-0">
            <div className="flex gap-1 md:gap-2 opacity-0 group-hover:opacity-100 transition-opacity p-1 bg-black/40 backdrop-blur-sm rounded-md border border-zinc-800/50">
              {Object.entries(REACTION_ICONS).map(([type, Icon]) => (
                <button
                  key={type}
                  onMouseEnter={playHover}
                  onClick={() => { playClick(); reactMutation.mutate(type); }}
                  className="p-1 text-zinc-700 hover:text-zinc-400 transition-colors flex items-center justify-center min-w-[20px] min-h-[20px]"
                >
                  <Icon className="w-3.5 h-3.5" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {reactions.length > 0 && (
          <div className="mt-2 flex gap-2">
            {reactions.map((r: any) => {
              const Icon = REACTION_ICONS[r.type];
              return (
                <div key={r.type} className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-zinc-900/50 border border-zinc-800">
                  {Icon && <Icon className="w-3 h-3 text-zinc-500" />}
                  <span className="text-[10px] font-mono text-zinc-500">{r.count}</span>
                </div>
              );
            })}
          </div>
        )}

        {post.mediaUrl && (
          <div className="mt-4 max-w-xl">
            {post.mediaType === 'video' ? (
              <video 
                src={post.mediaUrl} 
                controls 
                className="rounded border border-zinc-900 max-h-[400px] w-auto bg-black"
              />
            ) : (
              <img 
                src={post.mediaUrl} 
                alt="Echo attachment" 
                className="rounded border border-zinc-900 max-h-[400px] w-auto bg-black"
                loading="lazy"
              />
            )}
          </div>
        )}
        <div className="mt-4 flex items-center gap-3">
          <div className="h-px w-8 bg-zinc-900 group-hover:bg-zinc-800 transition-colors" />
          <span className="text-xs font-mono text-zinc-600 uppercase tracking-widest">
            {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
          </span>
        </div>
      </div>
    </div>
  );
}
