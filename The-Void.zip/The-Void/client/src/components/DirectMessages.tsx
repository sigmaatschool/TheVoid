import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { type DirectMessage } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, ArrowLeft, Send } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useAudioSystem } from "@/hooks/use-audio-system";
import { useAuth } from "@/hooks/use-auth";
import confetti from "canvas-confetti";

export function DirectMessages({ onClose }: { onClose: () => void }) {
  const { user } = useAuth();
  const { playHover, playClick } = useAudioSystem();
  const queryClient = useQueryClient();
  const [targetId, setTargetId] = useState("");
  const [content, setContent] = useState("");
  const [distortion, setDistortion] = useState<"none" | "glitch" | "blur" | "upside-down" | "vapor">("none");

  const { data: messages, isLoading } = useQuery<DirectMessage[]>({
    queryKey: ["/api/messages"],
    refetchInterval: 3000, // Fallback polling if WS fails
  });

  const mutation = useMutation({
    mutationFn: async (data: { receiverId: string; content: string; distortion: string }) => {
      await apiRequest("POST", "/api/messages", data);
    },
    onSuccess: () => {
      setContent("");
      setDistortion("none");
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#ffffff', '#555555']
      });
    },
  });

  useEffect(() => {
    const handleMessage = (e: any) => {
      if (e.detail?.type === "new_dm") {
        queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      }
    };
    window.addEventListener("ws_message", handleMessage);
    return () => window.removeEventListener("ws_message", handleMessage);
  }, [queryClient]);

  const sortedMessages = messages?.sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetId || !content) return;
    mutation.mutate({ receiverId: targetId, content, distortion });
  };

  return (
    <div className="flex flex-col gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between border-b border-zinc-900 pb-4">
        <button 
          onClick={() => { playClick(); onClose(); }}
          onMouseEnter={playHover}
          className="flex items-center gap-2 text-zinc-500 hover:text-white transition-colors uppercase font-mono text-[10px] tracking-widest"
        >
          <ArrowLeft className="w-3 h-3" /> Back to Void
        </button>
        <span className="text-[10px] font-mono text-zinc-700 uppercase tracking-[0.3em]">Encrypted Channel</span>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4 bg-zinc-950/50 p-6 rounded-lg border border-zinc-900">
        <div className="flex gap-4">
          <div className="flex flex-col gap-2 flex-1">
            <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Receiver ID</label>
            <div className="flex flex-col gap-1">
              <Input 
                value={targetId}
                onChange={(e) => setTargetId(e.target.value)}
                placeholder="User Identifier..."
                className="bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-700 h-8 text-xs font-mono"
              />
              <span className="text-[8px] font-mono text-zinc-600 uppercase tracking-tighter">
                Your ID: <span className="text-zinc-400 select-all">{user?.id || (user as any)?.externalId || (user as any)?.claims?.sub}</span>
              </span>
            </div>
          </div>
          <div className="flex flex-col gap-2 w-32">
            <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Distortion</label>
            <select 
              value={distortion}
              onMouseEnter={playHover}
              onChange={(e) => { playClick(); setDistortion(e.target.value as any); }}
              className="bg-zinc-900/50 border border-zinc-800 rounded px-2 h-8 text-[10px] font-mono text-zinc-400 uppercase tracking-widest focus:outline-none focus:border-zinc-700"
            >
              <option value="none">None</option>
              <option value="glitch">Glitch</option>
              <option value="blur">Blur</option>
              <option value="upside-down">Invert</option>
              <option value="vapor">Vapor</option>
            </select>
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Whisper</label>
          <div className="flex gap-2">
            <Input 
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Vanish into their mind..."
              className="bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-700 h-8 text-xs font-mono"
            />
            <Button 
              type="submit" 
              size="icon" 
              onMouseEnter={playHover}
              onClick={playClick}
              disabled={mutation.isPending || !targetId || !content}
              className="bg-zinc-800 hover:bg-zinc-700 h-8 w-8"
            >
              {mutation.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
            </Button>
          </div>
        </div>
      </form>

      <div className="space-y-4">
        {isLoading ? (
          <div className="flex justify-center py-10"><Loader2 className="w-5 h-5 animate-spin text-zinc-800" /></div>
        ) : sortedMessages?.length === 0 ? (
          <div className="text-center py-10 text-zinc-800 font-mono text-[10px] uppercase tracking-widest">No whispers heard</div>
        ) : (
          sortedMessages?.map((msg) => (
            <div key={msg.id} className={`flex flex-col gap-1 p-4 rounded border ${msg.senderId === user?.id ? 'border-zinc-800 bg-zinc-950/30' : 'border-zinc-900 bg-zinc-950/10'}`}>
              <div className="flex items-center justify-between text-[9px] font-mono uppercase tracking-widest mb-1">
                <span className={msg.senderId === user?.id ? 'text-zinc-400' : 'text-zinc-600'}>
                  {msg.senderId === user?.id ? 'Sent to ' + msg.receiverId : 'From ' + msg.senderName}
                </span>
                <span className="text-zinc-800">{formatDistanceToNow(new Date(msg.createdAt))} ago</span>
              </div>
              <p className={`text-sm font-mono text-zinc-300 break-words ${
                msg.distortion === 'glitch' ? 'glitch-text' : 
                msg.distortion === 'blur' ? 'blur-[2px] hover:blur-0 transition-all duration-500' : 
                msg.distortion === 'upside-down' ? 'rotate-180 inline-block' :
                msg.distortion === 'vapor' ? 'text-transparent bg-clip-text bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-500 animate-pulse' : 
                ''
              }`}>
                {msg.content}
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
