import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { WebSocketServer, WebSocket } from "ws";
import { WS_EVENTS } from "@shared/schema";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { registerObjectStorageRoutes } from "./replit_integrations/object_storage";

// Optimized custom bad words filter using pre-compiled regex and Set for O(1) lookups
const BANNED_WORDS = new Set(["bad", "offensive", "rude", "fuck", "shit", "ass", "bitch", "crap", "piss"]);
const BANNED_REGEX = new RegExp(`\\b(${Array.from(BANNED_WORDS).join('|')})\\b`, 'gi');

class SimpleFilter {
  clean(text: string): string {
    return text.replace(BANNED_REGEX, (match) => "*".repeat(match.length));
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Set up integrations
  await setupAuth(app);
  registerAuthRoutes(app);
  registerObjectStorageRoutes(app);

  const filter = new SimpleFilter();
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  const broadcast = (message: any) => {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  };

  const broadcastUserCount = () => {
    broadcast({ type: WS_EVENTS.USER_COUNT, payload: { count: wss.clients.size } });
  };

  wss.on("connection", (ws) => {
    broadcastUserCount();
    
    ws.on("message", (data) => {
      try {
        const message = JSON.parse(data.toString());
        if (message.type === "mouse_move") {
          // Broadcast to all other clients
          wss.clients.forEach((client) => {
            if (client !== ws && client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: "shadow_move",
                payload: {
                  id: (ws as any).id || ( (ws as any).id = Math.random().toString(36).substr(2, 9) ),
                  ...message.payload
                }
              }));
            }
          });
        }
      } catch (err) {
        console.error("WS Message Error:", err);
      }
    });

    ws.on("close", () => broadcastUserCount());
  });

  app.get(api.posts.list.path, async (_req, res) => {
    const posts = await storage.getPosts();
    res.json(posts);
  });

  const isAdmin = (user: any) => {
    if (!user) return false;
    const userId = String(user.id || user.externalId || user.claims?.sub);
    return userId === "41825561" || userId === "49721790";
  };

  app.post(api.posts.create.path, async (req, res) => {
    try {
      const { content, code, username, mediaUrl, mediaType, distortion } = req.body;
      console.log('POST /api/posts - body:', req.body);
      
      if (!content || typeof content !== 'string' || content.trim().length === 0) {
        return res.status(400).json({ message: "Content is required and cannot be empty" });
      }

      // Filter bad words
      const cleanedContent = filter.clean(content.trim());
      // Admin check: either via code (for backward compatibility if needed) or authenticated user ID
      const userIsAdmin = isAdmin(req.user) || code?.trim() === "Liam" || code?.trim() === "hunter";
      
      const post = await storage.createPost({ 
        content: cleanedContent,
        isGolden: userIsAdmin,
        username: username || null,
        mediaUrl: mediaUrl || null,
        mediaType: mediaType || null,
        distortion: distortion || "none"
      });
      
      broadcast({ type: WS_EVENTS.NEW_POST, payload: post });
      
      res.status(201).json(post);
    } catch (err) {
      console.error('SERVER ERROR [POST /api/posts]:', err);
      res.status(500).json({ message: "Internal server error. The void is unstable." });
    }
  });

  app.post("/api/posts/:id/react", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { type } = req.body;
      if (!type) return res.status(400).send("Reaction type required");

      const updatedPost = await storage.addReaction(id, type);
      if (!updatedPost) return res.status(404).send("Post not found");

      broadcast({ type: "post_updated", payload: updatedPost });
      res.json(updatedPost);
    } catch (err) {
      console.error('REACT ERROR:', err);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get(api.posts.get.path, async (req, res) => {
    const post = await storage.getPost(Number(req.params.id));
    if (!post) {
      return res.status(404).json({ message: "Post not found" });
    }
    res.json(post);
  });

  app.post("/api/admin/action", async (req, res) => {
    const { code, action, payload } = req.body;
    if (!isAdmin(req.user) && code !== "Liam" && code !== "hunter") {
      console.warn(`Unauthorized admin attempt. User: ${req.user ? (req.user as any).id : 'Anonymous'}`);
      return res.status(403).json({ message: "The void ignores your command." });
    }
    
    console.log(`Admin action triggered: ${action}`, payload);
    broadcast({ 
      type: WS_EVENTS.ADMIN_ACTION, 
      payload: { 
        action, 
        ...payload 
      } 
    });
    res.json({ success: true });
  });

  app.delete(api.posts.delete.path, async (req, res) => {
    const { code } = req.body;
    if (!isAdmin(req.user) && code !== "Liam" && code !== "hunter") {
      return res.status(403).json({ message: "The void ignores your attempt to erase its history." });
    }
    
    const success = await storage.deletePost(Number(req.params.id));
    if (!success) {
      return res.status(404).json({ message: "That echo has already faded." });
    }
    res.json({ success: true });
  });

  app.post("/api/posts/:id/mute", async (req, res) => {
    if (!isAdmin(req.user)) {
      return res.status(403).json({ message: "The void ignores your attempt to silence others." });
    }
    const id = parseInt(req.params.id);
    const { duration } = req.body;
    const updatedPost = await storage.toggleMute(id, duration);
    if (!updatedPost) return res.status(404).send("Post not found");
    broadcast({ type: "post_updated", payload: updatedPost });
    res.json(updatedPost);
  });

  app.get("/api/messages", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    const user = req.user as any;
    const userId = user.id || user.externalId || user.claims?.sub;
    if (!userId) return res.json([]);
    const messages = await storage.getDirectMessages(userId);
    res.json(messages);
  });

  app.post("/api/messages", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    const user = req.user as any;
    const { receiverId, content, distortion } = req.body;
    if (!receiverId || !content) return res.status(400).send("Missing fields");

    const senderId = user.id || user.externalId || user.claims?.sub;
    if (!senderId) {
      console.error("DM Error: No user ID found in session", user);
      return res.status(500).send("User identification failed");
    }

    const dm = await storage.createDirectMessage({
      senderId: String(senderId),
      receiverId: String(receiverId),
      senderName: user.firstName || user.claims?.first_name || "Anonymous",
      content,
      distortion: distortion || "none",
    });

    broadcast({ type: WS_EVENTS.NEW_DM, payload: dm });
    res.status(201).json(dm);
  });

  return httpServer;
}

// Seed function
async function seedDatabase() {
  const existingPosts = await storage.getPosts();
  if (existingPosts.length === 0) {
    await storage.createPost({ content: "Is anyone out there?" });
    await storage.createPost({ content: "The silence is loud today." });
    await storage.createPost({ content: "Just screaming into the void..." });
  }
}

seedDatabase().catch(console.error);
