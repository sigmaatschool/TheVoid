import { db } from "./db";
import { posts, directMessages, type InsertPost, type Post, type DirectMessage, type InsertDirectMessage } from "@shared/schema";
import { desc, eq, or } from "drizzle-orm";

export interface IStorage {
  getPosts(): Promise<Post[]>;
  getPost(id: number): Promise<Post | undefined>;
  createPost(post: InsertPost & { isGolden?: boolean }): Promise<Post>;
  deletePost(id: number): Promise<boolean>;
  toggleMute(id: number, durationMinutes?: number): Promise<Post | undefined>;
  getDirectMessages(userId: string): Promise<DirectMessage[]>;
  createDirectMessage(dm: InsertDirectMessage): Promise<DirectMessage>;
}

export class DatabaseStorage implements IStorage {
  async getDirectMessages(userId: string): Promise<DirectMessage[]> {
    return await db
      .select()
      .from(directMessages)
      .where(
        or(
          eq(directMessages.senderId, userId),
          eq(directMessages.receiverId, userId)
        )
      )
      .orderBy(desc(directMessages.createdAt));
  }

  async createDirectMessage(insertDm: InsertDirectMessage): Promise<DirectMessage> {
    const [dm] = await db
      .insert(directMessages)
      .values(insertDm)
      .returning();
    return dm;
  }
  async getPosts(): Promise<Post[]> {
    return await db.select().from(posts).orderBy(desc(posts.createdAt));
  }

  async getPost(id: number): Promise<Post | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.id, id));
    return post;
  }

  async createPost(insertPost: InsertPost & { isGolden?: boolean }): Promise<Post> {
    const [post] = await db
      .insert(posts)
      .values({
        content: insertPost.content,
        isGolden: insertPost.isGolden ?? false,
        username: insertPost.username || null,
        mediaUrl: insertPost.mediaUrl || null,
        mediaType: insertPost.mediaType || null,
        distortion: insertPost.distortion || "none",
        reactions: "[]",
      })
      .returning();
    return post;
  }

  async addReaction(postId: number, reactionType: string): Promise<Post | undefined> {
    const post = await this.getPost(postId);
    if (!post) return undefined;

    const reactions = JSON.parse(post.reactions || "[]");
    const existingIndex = reactions.findIndex((r: any) => r.type === reactionType);
    
    if (existingIndex > -1) {
      reactions[existingIndex].count += 1;
    } else {
      reactions.push({ type: reactionType, count: 1 });
    }

    const [updated] = await db
      .update(posts)
      .set({ reactions: JSON.stringify(reactions) })
      .where(eq(posts.id, postId))
      .returning();
    return updated;
  }

  async deletePost(id: number): Promise<boolean> {
    const [deleted] = await db.delete(posts).where(eq(posts.id, id)).returning();
    return !!deleted;
  }

  async toggleMute(id: number, durationMinutes?: number): Promise<Post | undefined> {
    const post = await this.getPost(id);
    if (!post) return undefined;
    
    const isMuting = !post.isMuted;
    let mutedUntil = null;
    
    if (isMuting && durationMinutes) {
      mutedUntil = new Date(Date.now() + durationMinutes * 60000);
    }

    const [updated] = await db
      .update(posts)
      .set({ 
        isMuted: isMuting,
        mutedUntil: mutedUntil
      })
      .where(eq(posts.id, id))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
