# VOID - Anonymous Message Board

## Overview

VOID is a minimalist, anonymous message board where users can post short text messages ("echoes") that appear in a real-time feed. The application features a dark, monochrome aesthetic with smooth animations and WebSocket-powered live updates. Posts are persisted to a PostgreSQL database and displayed in reverse chronological order.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, bundled via Vite
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state, with WebSocket integration for real-time updates
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom dark theme ("Void Theme" - monochrome, stark design)
- **Animations**: Framer Motion for smooth list entry and interaction animations
- **Fonts**: JetBrains Mono (headings/mono), Inter (body text)

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript (ESM modules)
- **Real-time**: WebSocket server (ws library) for broadcasting new posts to all connected clients
- **API Design**: RESTful endpoints defined in `shared/routes.ts` with Zod schemas for type-safe validation
- **Build**: Custom esbuild script for production bundling with selective dependency bundling for faster cold starts

### Data Storage
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with drizzle-zod for schema-to-validation integration
- **Schema Location**: `shared/schema.ts` - single posts table with id, content, and createdAt fields
- **Migrations**: Drizzle Kit with `db:push` command for schema synchronization

### Key Design Patterns
- **Shared Types**: The `shared/` directory contains schema definitions and API route contracts used by both client and server
- **Storage Interface**: `IStorage` interface in `server/storage.ts` abstracts database operations, enabling potential future storage swaps
- **Real-time Sync**: WebSocket broadcasts new posts immediately; client optimistically updates query cache to prevent duplicates

### Content Moderation
- Simple profanity filter implemented server-side that replaces banned words with asterisks before storing posts

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connection via `DATABASE_URL` environment variable
- **connect-pg-simple**: Session storage (configured but sessions not currently used for anonymous posts)

### Third-Party Libraries
- **Radix UI**: Accessible, unstyled component primitives (dialogs, tooltips, forms, etc.)
- **date-fns**: Relative time formatting for post timestamps
- **Framer Motion**: Animation library for smooth UI transitions
- **ws**: WebSocket server implementation for real-time updates

### Development Tools
- **Vite**: Development server with HMR and production bundling
- **Drizzle Kit**: Database migration and schema management
- **esbuild**: Server-side production bundling

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string (required)