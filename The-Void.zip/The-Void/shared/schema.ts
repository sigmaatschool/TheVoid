import { pgTable, text, serial, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  isGolden: boolean("is_golden").default(false).notNull(),
  username: text("username"),
  mediaUrl: text("media_url"),
  mediaType: text("media_type"), // 'image' or 'video'
  reactions: text("reactions").default("[]").notNull(), // JSON string: { type: string, count: number }[]
  distortion: text("distortion").default("none").notNull(), // 'none', 'glitch', 'blur', 'upside-down', 'vapor'
  isMuted: boolean("is_muted").default(false).notNull(),
  mutedUntil: timestamp("muted_until"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const directMessages = pgTable("direct_messages", {
  id: serial("id").primaryKey(),
  senderId: text("sender_id").notNull(),
  receiverId: text("receiver_id").notNull(),
  senderName: text("sender_name").notNull(),
  content: text("content").notNull(),
  distortion: text("distortion").default("none").notNull(), // 'none', 'glitch', 'blur', 'upside-down', 'vapor'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPostSchema = createInsertSchema(posts).omit({
  id: true,
  createdAt: true,
  isGolden: true,
  reactions: true,
}).extend({
  username: z.string().max(20).optional(),
  mediaUrl: z.string().url().optional(),
  mediaType: z.enum(["image", "video"]).optional(),
  distortion: z.enum(["none", "glitch", "blur", "upside-down", "vapor"]).optional(),
});

export const insertDirectMessageSchema = createInsertSchema(directMessages).omit({
  id: true,
  createdAt: true,
}).extend({
  distortion: z.enum(["none", "glitch", "blur", "upside-down", "vapor"]).optional(),
});

export * from "./models/auth";

// WebSocket message types
export const WS_EVENTS = {
  NEW_POST: "new_post",
  USER_COUNT: "user_count",
  NEW_DM: "new_dm",
  ADMIN_ACTION: "admin_action",
} as const;

export type Post = typeof posts.$inferSelect;
export type InsertPost = z.infer<typeof insertPostSchema>;
export type DirectMessage = typeof directMessages.$inferSelect;
export type InsertDirectMessage = z.infer<typeof insertDirectMessageSchema>;

export interface WsMessage {
  type: keyof typeof WS_EVENTS;
  payload: Post;
}
